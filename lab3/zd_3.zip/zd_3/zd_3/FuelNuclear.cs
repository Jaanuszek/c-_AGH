﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zd_3
{
    internal class FuelNuclear : Fuel
    {
        public FuelNuclear()
        {
            density = 0.8;
            material = "Nuclear";
        }

    }
}
